create definer = mairak_root@`%` view project_tasks as
select `p`.`project_id` AS `project_id`,
       `p`.`title`      AS `project_title`,
       `p`.`category`   AS `category`,
       `t`.`task_id`    AS `task_id`,
       `t`.`title`      AS `task_title`,
       `t`.`due_date`   AS `due_date`
from (`mairak_class`.`projects` `p`
         join `mairak_class`.`tasks` `t` on (`p`.`project_id` = `t`.`project_id`));

